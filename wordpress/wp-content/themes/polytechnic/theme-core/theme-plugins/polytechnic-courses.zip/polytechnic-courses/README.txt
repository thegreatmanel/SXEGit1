/*  UPDATE LOG  */

1.5 Language directory and get_text additions

1.4 Comments Support

1.3 Version Bump

1.2 Text Domain

1.1 Translation Recommendations

1.0 Original Gangsta